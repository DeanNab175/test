// Initialize the slider
$(document).ready(function(){

    // Flexslider
    $(document).ready(function() {
        $('.flexslider').flexslider({
            animation: "slide",
            slideshowSpeed: 5000,
            animationSpeed: 1200,
            controlNav: false,
            directionNav: true,
            prevText: "",
            nextText: ""
        });
    });

});